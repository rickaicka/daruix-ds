import * as _angular_core from '@angular/core';

declare class Ui {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Ui, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Ui, "drx-ui", never, {}, {}, never, never, true, never>;
}

type DrxCardSize = 'small' | 'medium' | 'large';
declare class CardComponent {
    readonly size: _angular_core.InputSignal<DrxCardSize>;
    readonly moduloColor: _angular_core.InputSignal<string>;
    readonly icon: _angular_core.InputSignal<string | null>;
    readonly title: _angular_core.InputSignal<string>;
    readonly description: _angular_core.InputSignal<string>;
    readonly platform: _angular_core.InputSignal<string[]>;
    readonly favorite: _angular_core.ModelSignal<boolean>;
    readonly favoritable: _angular_core.InputSignal<boolean>;
    readonly navigable: _angular_core.InputSignal<boolean>;
    readonly cardClasses: _angular_core.Signal<string>;
    readonly navigate: _angular_core.OutputEmitterRef<void>;
    protected onFavoriteClick(event: MouseEvent): void;
    protected onNavigateClick(event: MouseEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CardComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CardComponent, "drx-card", never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; "moduloColor": { "alias": "moduloColor"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "platform": { "alias": "platform"; "required": false; "isSignal": true; }; "favorite": { "alias": "favorite"; "required": false; "isSignal": true; }; "favoritable": { "alias": "favoritable"; "required": false; "isSignal": true; }; "navigable": { "alias": "navigable"; "required": false; "isSignal": true; }; }, { "favorite": "favoriteChange"; "navigate": "navigate"; }, never, ["*"], true, never>;
}

type DrxButtonVariant = 'primary' | 'secondary' | 'tertiary';
type DrxButtonSize = 'medium' | 'small';
type DrxButtonType = 'button' | 'submit' | 'reset';
type DrxButtonFont = 'quicksand' | 'gothic' | 'raleway';
declare class ButtonComponent {
    variant: _angular_core.InputSignal<DrxButtonVariant>;
    size: _angular_core.InputSignal<DrxButtonSize>;
    disabled: _angular_core.InputSignal<boolean>;
    type: _angular_core.InputSignal<DrxButtonType>;
    font: _angular_core.InputSignal<DrxButtonFont>;
    buttonClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ButtonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ButtonComponent, "drx-button", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "font": { "alias": "font"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class HubIconComponent {
    readonly name: _angular_core.InputSignal<string | null | undefined>;
    readonly action: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly iconComponent: _angular_core.Signal<_angular_core.Type<unknown>>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<HubIconComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<HubIconComponent, "app-hub-icon", never, { "name": { "alias": "name"; "required": false; "isSignal": true; }; "action": { "alias": "action"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

export { ButtonComponent, CardComponent, HubIconComponent, Ui };
export type { DrxButtonFont, DrxButtonSize, DrxButtonType, DrxButtonVariant, DrxCardSize };
